import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';

class ReadingScreen extends ConsumerStatefulWidget {
  final int novelId;
  final int chapterId;
  const ReadingScreen({super.key, required this.novelId, required this.chapterId});

  @override
  ConsumerState<ReadingScreen> createState() => _ReadingScreenState();
}

class _ReadingScreenState extends ConsumerState<ReadingScreen> {
  Map<String, dynamic>? _chapter;
  bool _loading = true;
  bool _showSettings = false;
  bool _showUi = true;
  double _fontSize = 18.0;
  String _readingTheme = 'dark';
  final _scrollController = ScrollController();
  double _readPercent = 0.0;

  static const _themes = {
    'dark':  Color(0xFF0A0A0F),
    'night': Color(0xFF0A0A0A),
    'sepia': Color(0xFFF8F1E3),
    'light': Color(0xFFFAFAF8),
  };
  static const _textColors = {
    'dark':  Color(0xFFF5F5F0),
    'night': Color(0xFFD0D0D0),
    'sepia': Color(0xFF3D2B1F),
    'light': Color(0xFF1A1A24),
  };

  @override
  void initState() {
    super.initState();
    _loadPrefs();
    _loadChapter();
    _scrollController.addListener(_onScroll);
  }

  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _fontSize = prefs.getDouble('fontSize') ?? 18.0;
      _readingTheme = prefs.getString('readingTheme') ?? 'dark';
    });
  }

  Future<void> _savePrefs() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('fontSize', _fontSize);
    await prefs.setString('readingTheme', _readingTheme);
  }

  Future<void> _loadChapter() async {
    setState(() => _loading = true);
    try {
      final data = await apiService.getChapter(widget.chapterId);
      setState(() { _chapter = data; _loading = false; });
    } catch (e) {
      setState(() => _loading = false);
    }
  }

  void _onScroll() {
    final max = _scrollController.position.maxScrollExtent;
    final cur = _scrollController.position.pixels;
    if (max > 0) {
      final pct = (cur / max * 100).clamp(0.0, 100.0);
      if ((pct - _readPercent).abs() > 5) {
        setState(() => _readPercent = pct);
        apiService.saveProgress(
          widget.novelId, widget.chapterId,
          cur.toInt(), pct,
        );
      }
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bg = _themes[_readingTheme] ?? const Color(0xFF0A0A0F);
    final textColor = _textColors[_readingTheme] ?? const Color(0xFFF5F5F0);

    return Scaffold(
      backgroundColor: bg,
      body: GestureDetector(
        onTap: () => setState(() => _showUi = !_showUi),
        child: Stack(children: [
          // Content
          _loading
            ? Center(child: CircularProgressIndicator(color: const Color(0xFFE85D26)))
            : _chapter == null
              ? Center(child: Text('Failed to load', style: TextStyle(color: textColor)))
              : _buildContent(textColor),

          // Top bar (auto-hide)
          AnimatedPositioned(
            duration: const Duration(milliseconds: 250),
            top: _showUi ? 0 : -80,
            left: 0, right: 0,
            child: _buildTopBar(textColor),
          ),

          // Progress bar
          Positioned(
            top: 0, left: 0, right: 0,
            child: LinearProgressIndicator(
              value: _readPercent / 100,
              backgroundColor: Colors.transparent,
              color: const Color(0xFFE85D26),
              minHeight: 2,
            ),
          ),

          // Bottom nav (auto-hide)
          AnimatedPositioned(
            duration: const Duration(milliseconds: 250),
            bottom: _showUi ? 0 : -80,
            left: 0, right: 0,
            child: _buildBottomNav(textColor),
          ),

          // Settings panel
          if (_showSettings) _buildSettingsPanel(textColor),
        ]),
      ),
    );
  }

  Widget _buildContent(Color textColor) {
    final chapter = _chapter!;
    final isLocked = chapter['isLocked'] == true;

    return SingleChildScrollView(
      controller: _scrollController,
      padding: const EdgeInsets.fromLTRB(20, 80, 20, 100),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Chapter title
        Text(
          chapter['title'] ?? '',
          style: TextStyle(
            fontFamily: 'NotoSerifTamil',
            fontSize: 22, fontWeight: FontWeight.bold,
            color: textColor,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          '${chapter['novelTitle']} · Chapter ${chapter['chapterNumber']}',
          style: TextStyle(fontSize: 13, color: textColor.withOpacity(0.5)),
        ),
        const SizedBox(height: 28),

        if (isLocked)
          _buildLockedView()
        else
          Html(
            data: (chapter['content'] as String? ?? '').replaceAll('\n', '<br/>'),
            style: {
              'body': Style(
                fontFamily: 'NotoSerifTamil',
                fontSize: FontSize(_fontSize),
                color: textColor,
                lineHeight: LineHeight.number(2.0),
                margin: Margins.zero,
              ),
            },
          ),

        // Author note
        if (chapter['authorNote'] != null) ...[
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFE85D26).withOpacity(0.08),
              border: Border.all(color: const Color(0xFFE85D26).withOpacity(0.2)),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('✍️ Author\'s Note', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: const Color(0xFFE85D26))),
              const SizedBox(height: 6),
              Text(chapter['authorNote'], style: TextStyle(fontSize: 13, color: textColor.withOpacity(0.7), fontFamily: 'NotoSerifTamil')),
            ]),
          ),
        ],
      ]),
    );
  }

  Widget _buildLockedView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(children: [
          Container(
            width: 64, height: 64,
            decoration: BoxDecoration(color: const Color(0xFFE85D26).withOpacity(0.1), borderRadius: BorderRadius.circular(16)),
            child: const Icon(Icons.lock_outline, color: Color(0xFFE85D26), size: 30),
          ),
          const SizedBox(height: 16),
          const Text('Premium Chapter', style: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFFF5F5F0))),
          const SizedBox(height: 8),
          const Text('Subscribe to read this chapter', style: TextStyle(color: Color(0xFFA0A0B0)), textAlign: TextAlign.center),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: () {},
            style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14)),
            child: const Text('Get Premium'),
          ),
        ]),
      ),
    );
  }

  Widget _buildTopBar(Color textColor) {
    return Container(
      color: const Color(0xFF0A0A0F).withOpacity(0.95),
      padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
      child: Row(children: [
        IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: textColor, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        Expanded(child: Text(
          _chapter?['novelTitle'] ?? '',
          style: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 14, color: textColor.withOpacity(0.7)),
          overflow: TextOverflow.ellipsis,
        )),
        IconButton(
          icon: Icon(Icons.settings_outlined, color: textColor, size: 20),
          onPressed: () => setState(() => _showSettings = !_showSettings),
        ),
      ]),
    );
  }

  Widget _buildBottomNav(Color textColor) {
    final chapter = _chapter;
    return Container(
      color: const Color(0xFF0A0A0F).withOpacity(0.95),
      padding: EdgeInsets.fromLTRB(16, 12, 16, MediaQuery.of(context).padding.bottom + 12),
      child: Row(children: [
        Expanded(
          child: chapter?['prevChapterId'] != null
            ? OutlinedButton.icon(
                onPressed: () => _navTo(chapter!['prevChapterId']),
                icon: const Icon(Icons.chevron_left, size: 16),
                label: const Text('முந்தைய', style: TextStyle(fontFamily: 'NotoSerifTamil')),
                style: OutlinedButton.styleFrom(foregroundColor: textColor, side: BorderSide(color: textColor.withOpacity(0.2))),
              )
            : const SizedBox.shrink(),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: chapter?['nextChapterId'] != null
            ? ElevatedButton.icon(
                onPressed: () => _navTo(chapter!['nextChapterId']),
                label: const Text('அடுத்தது', style: TextStyle(fontFamily: 'NotoSerifTamil')),
                icon: const Icon(Icons.chevron_right, size: 16),
              )
            : OutlinedButton(
                onPressed: () => Navigator.pop(context),
                style: OutlinedButton.styleFrom(foregroundColor: textColor, side: BorderSide(color: textColor.withOpacity(0.2))),
                child: const Text('முடிந்தது', style: TextStyle(fontFamily: 'NotoSerifTamil')),
              ),
        ),
      ]),
    );
  }

  Widget _buildSettingsPanel(Color textColor) {
    return Positioned(
      top: 70, right: 12,
      child: Material(
        color: const Color(0xFF16161F),
        borderRadius: BorderRadius.circular(16),
        elevation: 8,
        child: Container(
          width: 260,
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // Font size
            Text('Font Size: ${_fontSize.toInt()}px', style: TextStyle(fontSize: 12, color: textColor.withOpacity(0.6))),
            Row(children: [
              IconButton(icon: const Icon(Icons.remove), onPressed: () { setState(() => _fontSize = (_fontSize - 1).clamp(14, 24)); _savePrefs(); }, iconSize: 18),
              Expanded(child: Slider(value: _fontSize, min: 14, max: 24, divisions: 10, activeColor: const Color(0xFFE85D26), onChanged: (v) { setState(() => _fontSize = v); _savePrefs(); })),
              IconButton(icon: const Icon(Icons.add), onPressed: () { setState(() => _fontSize = (_fontSize + 1).clamp(14, 24)); _savePrefs(); }, iconSize: 18),
            ]),
            const SizedBox(height: 12),
            // Theme
            Text('Background', style: TextStyle(fontSize: 12, color: textColor.withOpacity(0.6))),
            const SizedBox(height: 8),
            Row(children: _themes.entries.map((e) {
              return GestureDetector(
                onTap: () { setState(() => _readingTheme = e.key); _savePrefs(); },
                child: Container(
                  margin: const EdgeInsets.only(right: 8),
                  width: 36, height: 36,
                  decoration: BoxDecoration(
                    color: e.value,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: _readingTheme == e.key ? const Color(0xFFE85D26) : Colors.transparent,
                      width: 2,
                    ),
                  ),
                ),
              );
            }).toList()),
          ]),
        ),
      ),
    );
  }

  void _navTo(int chapterId) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => ReadingScreen(novelId: widget.novelId, chapterId: chapterId)),
    );
  }
}
