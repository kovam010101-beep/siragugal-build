import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:shimmer/shimmer.dart';
import '../services/api_service.dart';
import '../services/ad_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<dynamic> _featured = [];
  List<dynamic> _trending = [];
  List<dynamic> _latest = [];
  bool _loading = true;

  BannerAd? _bannerAd;
  bool _isBannerAdLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadData();
    _initAdMob();
  }

  void _initAdMob() {
    AdService.initialize().then((_) {
      _bannerAd = AdService.createBanner(() {
        setState(() => _isBannerAdLoaded = true);
      });
    });
  }

  Future<void> _loadData() async {
    try {
      final fRes = await apiService.getFeatured();
      final tRes = await apiService.getTrending();
      final lRes = await apiService.getNovels({'pageSize': 6, 'sort': 'latest'});

      setState(() {
        _featured = fRes['items'] ?? [];
        _trending = tRes['items'] ?? [];
        _latest = lRes['items'] ?? [];
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset('assets/images/logo.png', height: 28, errorBuilder: (_, __, ___) => const Icon(Icons.menu_book, color: Color(0xFFE85D26))),
            const SizedBox(width: 8),
            const Text('சிறகுகள் நாவல்கள்', style: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 18, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
      body: _loading ? _buildShimmer(context) : RefreshIndicator(
        onRefresh: _loadData,
        child: SingleChildScrollView(
          padding: const EdgeInsets.only(bottom: 24),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // Featured carousel
            if (_featured.isNotEmpty) ...[
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 16, 16, 12),
                child: Text('சிறந்த நாவல்கள்', style: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 18, fontWeight: FontWeight.bold)),
              ),
              SizedBox(
                height: 240,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  itemCount: _featured.length,
                  itemBuilder: (ctx, i) => _buildFeaturedCard(context, _featured[i]),
                ),
              ),
            ],

            // Banner Ad Container
            if (_isBannerAdLoaded && _bannerAd != null)
              Container(
                alignment: Alignment.center,
                width: _bannerAd!.size.width.toDouble(),
                height: _bannerAd!.size.height.toDouble(),
                margin: const EdgeInsets.symmetric(vertical: 16),
                child: AdWidget(ad: _bannerAd!),
              ),

            // Trending Novels
            if (_trending.isNotEmpty) ...[
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 16, 16, 12),
                child: Text('தொடரும் நாவல்கள்', style: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 18, fontWeight: FontWeight.bold)),
              ),
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: _trending.length,
                itemBuilder: (ctx, i) => _buildTrendingCard(context, _trending[i]),
              ),
            ],
          ]),
        ),
      ),
    );
  }

  Widget _buildFeaturedCard(BuildContext context, dynamic novel) {
    return GestureDetector(
      onTap: () => context.push('/novel/${novel['slug']}'),
      child: Container(
        width: 140,
        margin: const EdgeInsets.symmetric(horizontal: 4),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: CachedNetworkImage(
                imageUrl: novel['coverUrl'] ?? '',
                fit: BoxFit.cover,
                placeholder: (_, __) => Container(color: Colors.white10),
                errorWidget: (_, __, ___) => Container(color: Colors.white10, child: const Icon(Icons.book, size: 40)),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(novel['title'] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 13, fontWeight: FontWeight.w600)),
          Text(novel['authorName'] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor)),
        ]),
      ),
    );
  }

  Widget _buildTrendingCard(BuildContext context, dynamic novel) {
    return InkWell(
      onTap: () => context.push('/novel/${novel['slug']}'),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: CachedNetworkImage(
              imageUrl: novel['coverUrl'] ?? '',
              width: 50, height: 75,
              fit: BoxFit.cover,
              errorWidget: (_, __, ___) => const Icon(Icons.book),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(novel['title'] ?? '', style: const TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 14, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(novel['authorName'] ?? '', style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)),
            ]),
          ),
          const Icon(Icons.chevron_right, size: 18),
        ]),
      ),
    );
  }

  Widget _buildShimmer(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: Colors.grey[800]!,
      highlightColor: Colors.grey[700]!,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(width: 150, height: 20, color: Colors.white),
          const SizedBox(height: 16),
          SizedBox(
            height: 200,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: 4,
              itemBuilder: (_, __) => Container(width: 120, margin: const EdgeInsets.only(right: 12), color: Colors.white),
            ),
          ),
        ]),
      ),
    );
  }
}
