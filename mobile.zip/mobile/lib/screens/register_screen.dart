import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../services/api_service.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _loading = false;
  String? _error;

  Future<void> _handleRegister() async {
    if (_nameController.text.isEmpty || _emailController.text.isEmpty || _passwordController.text.isEmpty) {
      setState(() => _error = 'அனைத்து விவரங்களையும் நிரப்பவும்.');
      return;
    }
    setState(() { _loading = true; _error = null; });
    try {
      await apiService.register(
        _nameController.text,
        _emailController.text,
        _passwordController.text,
      );
      if (mounted) {
        context.go('/');
      }
    } catch (e) {
      setState(() {
        _error = 'பதிவு செய்வதில் தோல்வி. மீண்டும் முயற்சிக்கவும்.';
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('பதிவு செய்தல்', style: TextStyle(fontFamily: 'NotoSerifTamil')),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const SizedBox(height: 30),
          const Icon(Icons.person_add_outlined, size: 64, color: Color(0xFFE85D26)),
          const SizedBox(height: 24),
          const Text(
            'புதிய கணக்கு',
            textAlign: TextAlign.center,
            style: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            'இலவச கணக்கை உருவாக்கி பல்லாயிரக்கணக்கான நாவல்களை வாசியுங்கள்',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 13, color: Theme.of(context).hintColor),
          ),
          const SizedBox(height: 32),

          if (_error != null) ...[
            Text(_error!, style: const TextStyle(color: Colors.redAccent, fontSize: 13), textAlign: TextAlign.center),
            const SizedBox(height: 16),
          ],

          TextField(
            controller: _nameController,
            decoration: const InputDecoration(
              hintText: 'முழு பெயர் (Full Name)',
              hintStyle: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 12),
              prefixIcon: Icon(Icons.person_outline),
            ),
          ),
          const SizedBox(height: 16),

          TextField(
            controller: _emailController,
            decoration: const InputDecoration(
              hintText: 'மின்னஞ்சல் முகவரி (Email)',
              hintStyle: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 12),
              prefixIcon: Icon(Icons.email_outlined),
            ),
          ),
          const SizedBox(height: 16),

          TextField(
            controller: _passwordController,
            obscureText: true,
            decoration: const InputDecoration(
              hintText: 'கடவுச்சொல் (Password)',
              hintStyle: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 12),
              prefixIcon: Icon(Icons.lock_outline),
            ),
          ),
          const SizedBox(height: 28),

          ElevatedButton(
            onPressed: _loading ? null : _handleRegister,
            child: _loading
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text('கணக்கை உருவாக்கு', style: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 15)),
          ),
          const SizedBox(height: 20),

          TextButton(
            onPressed: () => context.pop(),
            child: const Text('ஏற்கனவே கணக்கு உள்ளதா? உள்நுழையவும்', style: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 13)),
          ),
        ]),
      ),
    );
  }
}
