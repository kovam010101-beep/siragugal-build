import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class ProfileScreen extends ConsumerStatefulWidget {
  const ProfileScreen({super.key});

  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen> {
  Map<String, dynamic>? _user;
  Map<String, dynamic>? _subscription;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    try {
      final userBox = Hive.box('auth');
      final userData = userBox.get('user');
      final sub = await apiService.getSubscription();

      setState(() {
        _user = userData != null ? Map<String, dynamic>.from(userData) : null;
        _subscription = sub;
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  void _handleLogout() {
    apiService.logout();
    context.go('/login');
  }

  @override
  Widget build(BuildContext context) {
    final isDark = ref.watch(themeProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('சுயவிவரம்', style: TextStyle(fontFamily: 'NotoSerifTamil', fontWeight: FontWeight.bold)),
      ),
      body: _loading ? const Center(child: CircularProgressIndicator()) : SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const SizedBox(height: 20),
          // User Card Header
          Center(
            child: CircleAvatar(
              radius: 40,
              backgroundColor: const Color(0xFFE85D26).withOpacity(0.2),
              child: Text(
                (_user?['fullName'] ?? 'U').substring(0, 1).toUpperCase(),
                style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Color(0xFFE85D26)),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            _user?['fullName'] ?? 'Guest User',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          Text(
            _user?['email'] ?? 'guest@siragugal.com',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor),
          ),
          const SizedBox(height: 24),

          // User Tier Badge
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFE85D26).withOpacity(0.08),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE85D26).withOpacity(0.2)),
            ),
            child: Row(children: [
              const Icon(Icons.stars, color: Color(0xFFE85D26), size: 32),
              const SizedBox(width: 16),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(
                    _subscription != null ? 'Premium Member' : 'Free Member',
                    style: const TextStyle(fontFamily: 'NotoSerifTamil', fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    _subscription != null ? 'அனைத்து நாவல்களும் திறக்கப்பட்டுள்ளன' : 'பிரீமியம் நாவல்களைப் படிக்க மேம்படுத்தவும்',
                    style: const TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 11),
                  ),
                ]),
              ),
            ]),
          ),
          const SizedBox(height: 24),

          // Settings list
          Card(
            child: Column(children: [
              ListTile(
                leading: const Icon(Icons.dark_mode_outlined),
                title: const Text('இரவு முறை (Dark Theme)', style: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 14)),
                trailing: Switch(
                  value: isDark,
                  activeColor: const Color(0xFFE85D26),
                  onChanged: (val) => ref.read(themeProvider.notifier).state = val,
                ),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.delete_outline),
                title: const Text('தற்காலிக சேமிப்பை அழி (Clear Cache)', style: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 14)),
                onTap: () {
                  Hive.box('offline_chapters').clear();
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('தற்காலிக சேமிப்பு அழிக்கப்பட்டது')));
                },
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.logout, color: Colors.redAccent),
                title: const Text('வெளியேறு (Logout)', style: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 14, color: Colors.redAccent)),
                onTap: _handleLogout,
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}
