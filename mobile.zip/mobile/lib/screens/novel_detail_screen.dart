import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../services/api_service.dart';

class NovelDetailScreen extends StatefulWidget {
  final String slug;
  const NovelDetailScreen({super.key, required this.slug});

  @override
  State<NovelDetailScreen> createState() => _NovelDetailScreenState();
}

class _NovelDetailScreenState extends State<NovelDetailScreen> {
  Map<String, dynamic>? _novel;
  List<dynamic> _chapters = [];
  bool _loading = true;
  bool _isBookmarked = false;

  @override
  void initState() {
    super.initState();
    _loadNovelDetails();
  }

  Future<void> _loadNovelDetails() async {
    try {
      final res = await apiService.getNovel(widget.slug);
      final chs = await apiService.getChapters(res['id']);
      setState(() {
        _novel = res;
        _chapters = chs;
        _isBookmarked = res['isBookmarked'] == true;
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  Future<void> _toggleBookmark() async {
    if (_novel == null) return;
    try {
      await apiService.addBookmark(_novel!['id']);
      setState(() => _isBookmarked = !_isBookmarked);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(_isBookmarked ? 'நூலகத்தில் சேர்க்கப்பட்டது' : 'நூலகத்திலிருந்து நீக்கப்பட்டது')),
      );
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_novel == null) {
      return const Scaffold(body: Center(child: Text('விவரங்கள் கிடைக்கவில்லை')));
    }

    final novel = _novel!;
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 280,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  CachedNetworkImage(
                    imageUrl: novel['coverUrl'] ?? '',
                    fit: BoxFit.cover,
                  ),
                  Container(color: Colors.black.withOpacity(0.6)),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                // Novel Info header
                Text(novel['title'] ?? '', style: const TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text('எழுதியவர்: ${novel['authorName'] ?? ''}', style: TextStyle(fontSize: 14, color: Theme.of(context).hintColor)),
                const SizedBox(height: 16),

                Row(children: [
                  ElevatedButton(
                    onPressed: () {
                      if (_chapters.isNotEmpty) {
                        context.push('/read/${novel['id']}/${_chapters.first['id']}');
                      }
                    },
                    style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12)),
                    child: const Text('படிக்க தொடங்கு', style: TextStyle(fontFamily: 'NotoSerifTamil')),
                  ),
                  const SizedBox(width: 12),
                  IconButton(
                    onPressed: _toggleBookmark,
                    icon: Icon(_isBookmarked ? Icons.bookmark : Icons.bookmark_border, color: const Color(0xFFE85D26)),
                  ),
                ]),

                const SizedBox(height: 24),
                const Text('சுருக்கம்', style: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(novel['description'] ?? '', style: const TextStyle(fontSize: 14, height: 1.6)),
                const SizedBox(height: 24),

                const Text('அத்தியாயங்கள்', style: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
              ]),
            ),
          ),
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (ctx, idx) {
                final ch = _chapters[idx];
                final isLocked = ch['isLocked'] == true;
                return ListTile(
                  title: Text(ch['title'] ?? '', style: const TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 14)),
                  trailing: isLocked ? const Icon(Icons.lock, size: 16, color: Color(0xFFE85D26)) : const Icon(Icons.chevron_right, size: 16),
                  onTap: () => context.push('/read/${novel['id']}/${ch['id']}'),
                );
              },
              childCount: _chapters.length,
            ),
          ),
        ],
      ),
    );
  }
}
