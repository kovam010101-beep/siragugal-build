import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'screens/home_screen.dart';
import 'screens/novel_detail_screen.dart';
import 'screens/reading_screen.dart';
import 'screens/login_screen.dart';
import 'screens/register_screen.dart';
import 'screens/library_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/plans_screen.dart';
import 'screens/search_screen.dart';
import 'screens/shell_screen.dart';
import 'screens/categories_screen.dart';

final routerProvider = Provider<GoRouter>((ref) {
  final authBox = Hive.box('auth');
  final isLoggedIn = authBox.get('access_token') != null;

  return GoRouter(
    initialLocation: '/',
    redirect: (context, state) {
      final protected = ['/library', '/profile', '/settings'];
      if (protected.any((p) => state.matchedLocation.startsWith(p)) && !isLoggedIn) {
        return '/login?redirect=${state.matchedLocation}';
      }
      return null;
    },
    routes: [
      ShellRoute(
        builder: (ctx, state, child) => ShellScreen(child: child),
        routes: [
          GoRoute(path: '/', builder: (ctx, s) => const HomeScreen()),
          GoRoute(path: '/categories', builder: (ctx, s) => const CategoriesScreen()),
          GoRoute(path: '/library', builder: (ctx, s) => const LibraryScreen()),
          GoRoute(path: '/plans', builder: (ctx, s) => const PlansScreen()),
          GoRoute(path: '/profile', builder: (ctx, s) => const ProfileScreen()),
        ],
      ),
      GoRoute(path: '/search', builder: (ctx, s) => SearchScreen(query: s.uri.queryParameters['q'] ?? '')),
      GoRoute(path: '/novel/:slug', builder: (ctx, s) => NovelDetailScreen(slug: s.pathParameters['slug']!)),
      GoRoute(path: '/read/:novelId/:chapterId', builder: (ctx, s) => ReadingScreen(
        novelId: int.parse(s.pathParameters['novelId']!),
        chapterId: int.parse(s.pathParameters['chapterId']!),
      )),
      GoRoute(path: '/login', builder: (ctx, s) => LoginScreen(redirect: s.uri.queryParameters['redirect'])),
      GoRoute(path: '/register', builder: (ctx, s) => const RegisterScreen()),
    ],
  );
});
