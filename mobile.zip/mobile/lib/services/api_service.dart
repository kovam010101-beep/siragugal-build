import 'package:dio/dio.dart';
import 'package:hive_flutter/hive_flutter.dart';

class ApiService {
  static const _base = 'https://api.siragugal.com/api';
  late final Dio _dio;

  ApiService() {
    _dio = Dio(BaseOptions(
      baseUrl: _base,
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 15),
      headers: {'Content-Type': 'application/json'},
    ));

    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) {
        final token = Hive.box('auth').get('access_token');
        if (token != null) options.headers['Authorization'] = 'Bearer $token';
        return handler.next(options);
      },
      onError: (error, handler) async {
        if (error.response?.statusCode == 401) {
          final refreshed = await _refreshToken();
          if (refreshed) {
            final token = Hive.box('auth').get('access_token');
            error.requestOptions.headers['Authorization'] = 'Bearer $token';
            final retry = await _dio.fetch(error.requestOptions);
            return handler.resolve(retry);
          }
        }
        return handler.next(error);
      },
    ));
  }

  Future<bool> _refreshToken() async {
    final box = Hive.box('auth');
    final refresh = box.get('refresh_token');
    if (refresh == null) return false;
    try {
      final res = await Dio().post('$_base/auth/refresh', data: {'refreshToken': refresh});
      box.put('access_token', res.data['accessToken']);
      box.put('refresh_token', res.data['refreshToken']);
      return true;
    } catch { return false; }
  }

  // ── Auth ──────────────────────────────────────────────────────
  Future<Map<String, dynamic>> login(String email, String password) async {
    final res = await _dio.post('/auth/login', data: {'email': email, 'password': password});
    _saveAuth(res.data);
    return res.data;
  }

  Future<Map<String, dynamic>> register(String name, String email, String password) async {
    final res = await _dio.post('/auth/register', data: {'fullName': name, 'email': email, 'password': password});
    _saveAuth(res.data);
    return res.data;
  }

  Future<Map<String, dynamic>> sendOtp(String phone) async {
    final res = await _dio.post('/auth/otp/send', data: {'phoneNumber': phone});
    return res.data;
  }

  Future<Map<String, dynamic>> verifyOtp(String phone, String otp) async {
    final res = await _dio.post('/auth/otp/verify', data: {'phoneNumber': phone, 'otp': otp});
    _saveAuth(res.data);
    return res.data;
  }

  void logout() {
    Hive.box('auth').clear();
    try { _dio.post('/auth/logout'); } catch {}
  }

  void _saveAuth(Map<String, dynamic> data) {
    final box = Hive.box('auth');
    box.put('access_token', data['accessToken']);
    box.put('refresh_token', data['refreshToken']);
    box.put('user', data['user']);
  }

  // ── Novels ────────────────────────────────────────────────────
  Future<Map<String, dynamic>> getFeatured() async => (await _dio.get('/novels/featured')).data;
  Future<Map<String, dynamic>> getTrending() async => (await _dio.get('/novels/trending')).data;
  Future<Map<String, dynamic>> getNovels(Map<String, dynamic> params) async =>
      (await _dio.get('/novels', queryParameters: params)).data;
  Future<Map<String, dynamic>> getNovel(String slug) async => (await _dio.get('/novels/$slug')).data;
  Future<List<dynamic>> getChapters(int novelId) async => (await _dio.get('/novels/$novelId/chapters')).data;

  // ── Chapters ──────────────────────────────────────────────────
  Future<Map<String, dynamic>> getChapter(int id) async {
    // Check offline first
    final box = Hive.box('offline_chapters');
    final cached = box.get('chapter_$id');
    if (cached != null) return Map<String, dynamic>.from(cached);
    final res = await _dio.get('/chapters/$id');
    return res.data;
  }

  Future<void> downloadChapter(int id, Map<String, dynamic> data) async {
    final box = Hive.box('offline_chapters');
    await box.put('chapter_$id', data);
  }

  // ── Reader ────────────────────────────────────────────────────
  Future<void> saveProgress(int novelId, int? chapterId, int scroll, double percent) async {
    await _dio.post('/reader/history', data: {
      'novelId': novelId, 'chapterId': chapterId,
      'scrollPosition': scroll, 'readPercent': percent,
    });
  }

  Future<List<dynamic>> getHistory() async => (await _dio.get('/reader/history')).data;
  Future<List<dynamic>> getBookmarks() async => (await _dio.get('/reader/bookmarks')).data;
  Future<void> addBookmark(int novelId) async =>
      await _dio.post('/reader/bookmarks', data: {'novelId': novelId});

  // ── Payments ──────────────────────────────────────────────────
  Future<List<dynamic>> getPlans() async => (await _dio.get('/payments/plans')).data;

  Future<Map<String, dynamic>> createOrder(int planId) async =>
      (await _dio.post('/payments/create-order', data: {'planId': planId})).data;

  Future<bool> verifyPayment(String orderId, String paymentId, String signature, int planId) async {
    final res = await _dio.post('/payments/verify', data: {
      'razorpayOrderId': orderId,
      'razorpayPaymentId': paymentId,
      'razorpaySignature': signature,
      'paymentType': 'subscription',
      'entityId': planId,
    });
    return res.data['success'] == true;
  }

  Future<Map<String, dynamic>?> getSubscription() async {
    try { return (await _dio.get('/payments/subscription')).data; }
    catch { return null; }
  }

  // ── Notifications ─────────────────────────────────────────────
  Future<void> registerPushToken(String token, String platform) async {
    await _dio.post('/reader/push-token', data: {'token': token, 'platform': platform});
  }
}

// Singleton
final apiService = ApiService();
