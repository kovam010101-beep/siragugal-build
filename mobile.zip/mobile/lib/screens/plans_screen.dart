import 'package:flutter/material.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import '../services/api_service.dart';

class PlansScreen extends StatefulWidget {
  const PlansScreen({super.key});

  @override
  State<PlansScreen> createState() => _PlansScreenState();
}

class _PlansScreenState extends State<PlansScreen> {
  late final Razorpay _razorpay;
  List<dynamic> _plans = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
    _loadPlans();
  }

  Future<void> _loadPlans() async {
    try {
      final res = await apiService.getPlans();
      setState(() { _plans = res; _loading = false; });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  void _startCheckout(dynamic plan) async {
    try {
      final order = await apiService.createOrder(plan['id']);
      final options = {
        'key': 'rzp_test_YourTestKeyHere', // Setup dynamically or fetch from config
        'amount': order['amount'],
        'name': 'Siragugal Novels',
        'order_id': order['id'],
        'description': plan['name'],
        'prefill': {'contact': '9876543210', 'email': 'user@siragugal.com'},
        'external': {
          'wallets': ['paytm']
        }
      };
      _razorpay.open(options);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ஆர்டர் உருவாக்குவதில் பிழை')));
    }
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) async {
    // Verify on backend
    try {
      // Decode or retrieve original planId from cached state
      final success = await apiService.verifyPayment(
        response.orderId!,
        response.paymentId!,
        response.signature!,
        _plans.first['id'],
      );
      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('சந்தா வெற்றிகரமாக செயல்படுத்தப்பட்டது! 🎉')));
      }
    } catch (_) {}
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('கட்டணம் தோல்வியுற்றது: ${response.message}')));
  }

  void _handleExternalWallet(ExternalWalletResponse response) {}

  @override
  void dispose() {
    _razorpay.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('பிரீமியம் சந்தாக்கள்', style: TextStyle(fontFamily: 'NotoSerifTamil', fontWeight: FontWeight.bold)),
      ),
      body: _loading ? const Center(child: CircularProgressIndicator()) : SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text(
            'பிரீமியம் நாவல்களைப் படியுங்கள்!',
            textAlign: TextAlign.center,
            style: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            'குறைந்த விலையில் சிறந்த எழுத்தாளர்களின் கற்பனை உலகில் இணையுங்கள்.',
            textAlign: TextAlign.center,
            style: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 12),
          ),
          const SizedBox(height: 24),

          ..._plans.map((plan) {
            return Card(
              margin: const EdgeInsets.only(bottom: 16),
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(plan['name'] ?? '', style: const TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFFE85D26))),
                  const SizedBox(height: 8),
                  Text('₹${plan['price']} / ${plan['durationMonths']} மாதங்கள்', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 12),
                  ...((plan['perks'] as List? ?? ['அனைத்து பிரீமியம் நாவல்களையும் வரம்பற்ற வாசிப்பு', 'விளம்பரங்கள் அற்ற வாசிப்பு அணுபவம்', 'ஆஃப்லைனில் வாசிக்க பதிவிறக்கம் செய்தல்']).map((perk) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(children: [
                        const Icon(Icons.check_circle_outline, color: Color(0xFFE85D26), size: 16),
                        const SizedBox(width: 8),
                        Expanded(child: Text(perk, style: const TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 12))),
                      ]),
                    );
                  }).toList()),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () => _startCheckout(plan),
                    style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
                    child: const Text('இப்போது மேம்படுத்தவும்', style: TextStyle(fontFamily: 'NotoSerifTamil', fontWeight: FontWeight.bold)),
                  ),
                ]),
              ),
            );
          }).toList(),
        ]),
      ),
    );
  }
}
