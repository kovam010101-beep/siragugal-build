import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static const _brandOrange = Color(0xFFE85D26);
  static const _brandOrangeLight = Color(0xFFF4A261);
  static const _brandGold = Color(0xFFE9C46A);

  static ThemeData get darkTheme => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: ColorScheme.dark(
      primary: _brandOrange,
      secondary: _brandOrangeLight,
      tertiary: _brandGold,
      surface: const Color(0xFF16161F),
      background: const Color(0xFF0A0A0F),
      onPrimary: Colors.white,
      onSurface: const Color(0xFFF5F5F0),
    ),
    scaffoldBackgroundColor: const Color(0xFF0A0A0F),
    cardColor: const Color(0xFF16161F),
    textTheme: _tamilTextTheme(Brightness.dark),
    appBarTheme: const AppBarTheme(
      backgroundColor: Color(0xFF0A0A0F),
      elevation: 0,
      centerTitle: true,
      foregroundColor: Color(0xFFF5F5F0),
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: Color(0xFF16161F),
      selectedItemColor: _brandOrange,
      unselectedItemColor: Color(0xFF606070),
      elevation: 0,
      type: BottomNavigationBarType.fixed,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: _brandOrange,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        padding: const EdgeInsets.symmetric(vertical: 14),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: const Color(0xFF16161F),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0x14FFFFFF)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0x14FFFFFF)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: _brandOrange, width: 1.5),
      ),
    ),
  );

  static ThemeData get lightTheme => ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    colorScheme: ColorScheme.light(
      primary: _brandOrange,
      secondary: _brandOrangeLight,
      surface: Colors.white,
      background: const Color(0xFFFAFAF8),
      onSurface: const Color(0xFF1A1A24),
    ),
    scaffoldBackgroundColor: const Color(0xFFFAFAF8),
    textTheme: _tamilTextTheme(Brightness.light),
    appBarTheme: const AppBarTheme(
      backgroundColor: Color(0xFFFAFAF8),
      elevation: 0,
      foregroundColor: Color(0xFF1A1A24),
    ),
  );

  static TextTheme _tamilTextTheme(Brightness brightness) {
    final color = brightness == Brightness.dark ? const Color(0xFFF5F5F0) : const Color(0xFF1A1A24);
    return TextTheme(
      displayLarge:  GoogleFonts.notoSerifTamil(fontSize: 32, fontWeight: FontWeight.bold, color: color),
      displayMedium: GoogleFonts.notoSerifTamil(fontSize: 26, fontWeight: FontWeight.bold, color: color),
      headlineLarge: GoogleFonts.notoSerifTamil(fontSize: 22, fontWeight: FontWeight.w700, color: color),
      headlineMedium:GoogleFonts.notoSerifTamil(fontSize: 18, fontWeight: FontWeight.w600, color: color),
      bodyLarge:     GoogleFonts.notoSerifTamil(fontSize: 16, height: 2.0, color: color),
      bodyMedium:    GoogleFonts.notoSerifTamil(fontSize: 14, height: 1.8, color: color),
      labelLarge:    const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: _brandOrange),
    );
  }
}

// Theme provider (simple bool for demo; use Riverpod in production)
import 'package:flutter_riverpod/flutter_riverpod.dart';
final themeProvider = StateProvider<bool>((ref) => true); // true = dark
