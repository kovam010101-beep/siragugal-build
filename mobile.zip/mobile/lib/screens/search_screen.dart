import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../services/api_service.dart';

class SearchScreen extends StatefulWidget {
  final String query;
  const SearchScreen({super.key, this.query = ''});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _searchController = TextEditingController();
  List<dynamic> _results = [];
  bool _searching = false;

  final List<String> _suggestedGenres = ['காதல் (Romance)', 'குடும்பம் (Family)', 'திகில் (Thriller)', 'மர்மம் (Mystery)'];

  @override
  void initState() {
    super.initState();
    if (widget.query.isNotEmpty) {
      _searchController.text = widget.query;
      _performSearch(widget.query);
    }
  }

  Future<void> _performSearch(String q) async {
    if (q.isEmpty) return;
    setState(() => _searching = true);
    try {
      final res = await apiService.getNovels({'search': q});
      setState(() {
        _results = res['items'] ?? [];
        _searching = false;
      });
    } catch (_) {
      setState(() => _searching = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('தேடல்', style: TextStyle(fontFamily: 'NotoSerifTamil')),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Search input field
          TextField(
            controller: _searchController,
            decoration: InputDecoration(
              hintText: 'நாவல்கள் அல்லது ஆசிரியர்களைத் தேடுங்கள்...',
              hintStyle: const TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 13),
              suffixIcon: IconButton(
                icon: const Icon(Icons.search, color: Color(0xFFE85D26)),
                onPressed: () => _performSearch(_searchController.text),
              ),
            ),
            onSubmitted: _performSearch,
          ),
          const SizedBox(height: 20),

          if (_results.isEmpty && !_searching) ...[
            const Text('பரிந்துரைக்கப்பட்ட தலைப்புகள்', style: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 15, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _suggestedGenres.map((genre) {
                return ActionChip(
                  label: Text(genre, style: const TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 12)),
                  backgroundColor: Theme.of(context).cardColor,
                  onPressed: () {
                    _searchController.text = genre.split(' ').first;
                    _performSearch(_searchController.text);
                  },
                );
              }).toList(),
            ),
          ],

          if (_searching)
            const Expanded(child: Center(child: CircularProgressIndicator()))
          else
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.only(top: 16),
                itemCount: _results.length,
                itemBuilder: (ctx, i) {
                  final novel = _results[i];
                  return ListTile(
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: CachedNetworkImage(
                        imageUrl: novel['coverUrl'] ?? '',
                        width: 40, height: 60,
                        fit: BoxFit.cover,
                        errorWidget: (_, __, ___) => const Icon(Icons.book),
                      ),
                    ),
                    title: Text(novel['title'] ?? '', style: const TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 14, fontWeight: FontWeight.bold)),
                    subtitle: Text(novel['authorName'] ?? '', style: const TextStyle(fontSize: 12)),
                    onTap: () => context.push('/novel/${novel['slug']}'),
                  );
                },
              ),
            ),
        ]),
      ),
    );
  }
}
