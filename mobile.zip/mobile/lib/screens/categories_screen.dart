import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});

  static const List<Map<String, dynamic>> _categories = [
    {'name': 'காதல்', 'icon': Icons.favorite, 'color': Color(0xFFE91E63)},
    {'name': 'வரலாறு', 'icon': Icons.account_balance, 'color': Color(0xFF795548)},
    {'name': 'மர்மம்', 'icon': Icons.search, 'color': Color(0xFF607D8B)},
    {'name': 'சமூக', 'icon': Icons.people, 'color': Color(0xFF4CAF50)},
    {'name': 'திரில்லர்', 'icon': Icons.bolt, 'color': Color(0xFFF44336)},
    {'name': 'ஆன்மீகம்', 'icon': Icons.self_improvement, 'color': Color(0xFFFF9800)},
    {'name': 'நகைச்சுவை', 'icon': Icons.sentiment_very_satisfied, 'color': Color(0xFFFFC107)},
    {'name': 'சிறுகதைகள்', 'icon': Icons.menu_book, 'color': Color(0xFF9C27B0)},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('பிரிவுகள்', style: TextStyle(fontFamily: 'NotoSerifTamil', fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => context.push('/search'),
          ),
        ],
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: 1.5,
        ),
        itemCount: _categories.length,
        itemBuilder: (context, index) {
          final cat = _categories[index];
          return InkWell(
            onTap: () {
              context.push('/search?q=${cat['name']}');
            },
            borderRadius: BorderRadius.circular(16),
            child: Container(
              decoration: BoxDecoration(
                color: cat['color'].withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: cat['color'].withOpacity(0.3)),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(cat['icon'], color: cat['color'], size: 32),
                  const SizedBox(height: 12),
                  Text(
                    cat['name'],
                    style: TextStyle(
                      fontFamily: 'NotoSerifTamil',
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: cat['color'],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
