import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:shimmer/shimmer.dart';
import '../services/api_service.dart';
import '../services/ad_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;
  List<dynamic> _featured = [];
  List<dynamic> _trending = [];
  List<dynamic> _latest = [];
  bool _loading = true;

  BannerAd? _bannerAd;
  bool _isBannerAdLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadData();
    _initAdMob();
  }

  void _initAdMob() {
    AdService.initialize().then((_) {
      _bannerAd = AdService.createBanner(() {
        setState(() => _isBannerAdLoaded = true);
      });
    });
  }

  Future<void> _loadData() async {
    try {
      final results = await Future.wait([
        apiService.getFeatured().catchError((_) => <String, dynamic>{}),
        apiService.getTrending().catchError((_) => <String, dynamic>{}),
        apiService.getNovels({'pageSize': 6, 'sort': 'latest'}).catchError((_) => <String, dynamic>{}),
      ]);

      setState(() {
        _featured = results[0]['items'] is List ? results[0]['items'] : [];
        _trending = results[1]['items'] is List ? results[1]['items'] : [];
        _latest = results[2]['items'] is List ? results[2]['items'] : [];
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset('assets/images/logo.png', height: 28, errorBuilder: (_, __, ___) => const Icon(Icons.menu_book, color: Color(0xFFE85D26))),
            const SizedBox(width: 8),
            const Text('சிறகுகள் நாவல்கள்', style: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 18, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
      body: _loading ? _buildShimmer(context) : RefreshIndicator(
        onRefresh: _loadData,
        child: SingleChildScrollView(
          padding: const EdgeInsets.only(bottom: 24),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (_featured.isNotEmpty) _buildHorizontalList(context, 'சிறந்த நாவல்கள்', _featured),

            if (_isBannerAdLoaded && _bannerAd != null)
              Container(
                alignment: Alignment.center,
                width: _bannerAd!.size.width.toDouble(),
                height: _bannerAd!.size.height.toDouble(),
                margin: const EdgeInsets.symmetric(vertical: 16),
                child: AdWidget(ad: _bannerAd!),
              ),

            if (_latest.isNotEmpty) _buildHorizontalList(context, 'புதிய நாவல்கள்', _latest),

            if (_trending.isNotEmpty) ...[
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 24, 16, 12),
                child: Text('தொடரும் நாவல்கள்', style: TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 18, fontWeight: FontWeight.bold)),
              ),
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: _trending.length,
                itemBuilder: (ctx, i) => _buildTrendingCard(context, _trending[i]),
              ),
            ],

            if (_featured.isEmpty && _latest.isEmpty && _trending.isEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 80),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.library_books, size: 64, color: Theme.of(context).hintColor.withOpacity(0.3)),
                      const SizedBox(height: 16),
                      Text('நாவல்கள் எதுவும் கிடைக்கவில்லை', style: TextStyle(fontFamily: 'NotoSerifTamil', color: Theme.of(context).hintColor)),
                      const SizedBox(height: 8),
                      TextButton.icon(
                        onPressed: _loadData,
                        icon: const Icon(Icons.refresh),
                        label: const Text('மீண்டும் முயற்சி செய் (Retry)', style: TextStyle(fontFamily: 'NotoSerifTamil')),
                      )
                    ],
                  ),
                ),
              ),
          ]),
        ),
      ),
    );
  }

  Widget _buildHorizontalList(BuildContext context, String title, List<dynamic> novels) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
          child: Text(title, style: const TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 18, fontWeight: FontWeight.bold)),
        ),
        SizedBox(
          height: 220,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: novels.length,
            itemBuilder: (ctx, i) => _buildCard(context, novels[i]),
          ),
        ),
      ],
    );
  }

  Widget _buildCard(BuildContext context, dynamic novel) {
    return GestureDetector(
      onTap: () => context.push('/novel/${novel['slug']}'),
      child: Container(
        width: 120,
        margin: const EdgeInsets.symmetric(horizontal: 6),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: CachedNetworkImage(
                imageUrl: novel['coverUrl'] ?? '',
                fit: BoxFit.cover,
                width: double.infinity,
                memCacheWidth: 240,
                memCacheHeight: 320,
                placeholder: (_, __) => Container(color: Colors.white10),
                errorWidget: (_, __, ___) => Container(color: Colors.white10, child: const Icon(Icons.book, size: 40)),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(novel['title'] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 13, fontWeight: FontWeight.w600)),
          Text(novel['authorName'] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor)),
        ]),
      ),
    );
  }

  Widget _buildTrendingCard(BuildContext context, dynamic novel) {
    return InkWell(
      onTap: () => context.push('/novel/${novel['slug']}'),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: CachedNetworkImage(
              imageUrl: novel['coverUrl'] ?? '',
              width: 50, height: 75,
              fit: BoxFit.cover,
              memCacheWidth: 100,
              memCacheHeight: 150,
              errorWidget: (_, __, ___) => const Icon(Icons.book),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(novel['title'] ?? '', style: const TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 14, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(novel['authorName'] ?? '', style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)),
            ]),
          ),
          const Icon(Icons.chevron_right, size: 18),
        ]),
      ),
    );
  }

  Widget _buildShimmer(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: Colors.grey[850]!,
      highlightColor: Colors.grey[800]!,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(width: 150, height: 24, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(4))),
          const SizedBox(height: 16),
          SizedBox(
            height: 220,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: 4,
              itemBuilder: (_, __) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(width: 120, height: 160, margin: const EdgeInsets.only(right: 12), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12))),
                const SizedBox(height: 8),
                Container(width: 100, height: 12, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(2))),
                const SizedBox(height: 4),
                Container(width: 60, height: 10, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(2))),
              ]),
            ),
          ),
          const SizedBox(height: 32),
          Container(width: 150, height: 24, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(4))),
          const SizedBox(height: 16),
          SizedBox(
            height: 220,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: 4,
              itemBuilder: (_, __) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(width: 120, height: 160, margin: const EdgeInsets.only(right: 12), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12))),
                const SizedBox(height: 8),
                Container(width: 100, height: 12, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(2))),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}
