import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../services/api_service.dart';

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key});

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  List<dynamic> _bookmarks = [];
  List<dynamic> _history = [];
  List<dynamic> _offlineChapters = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadLibrary();
  }

  Future<void> _loadLibrary() async {
    try {
      final bRes = await apiService.getBookmarks();
      final hRes = await apiService.getHistory();

      // Read offline chapters from Hive box
      final box = Hive.box('offline_chapters');
      final offline = box.keys.map((k) {
        final data = box.get(k);
        return {
          'id': int.tryParse(k.toString().replaceFirst('chapter_', '')) ?? 0,
          'title': data['title'] ?? '',
          'novelTitle': data['novelTitle'] ?? '',
          'novelId': data['novelId'] ?? 0,
        };
      }).toList();

      setState(() {
        _bookmarks = bRes;
        _history = hRes;
        _offlineChapters = offline;
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('எனது நூலகம்', style: TextStyle(fontFamily: 'NotoSerifTamil', fontWeight: FontWeight.bold)),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: const Color(0xFFE85D26),
          labelColor: const Color(0xFFE85D26),
          unselectedLabelColor: Theme.of(context).hintColor,
          tabs: const [
            Tab(child: Text('புத்தகங்கள்', style: TextStyle(fontFamily: 'NotoSerifTamil'))),
            Tab(child: Text('வரலாறு', style: TextStyle(fontFamily: 'NotoSerifTamil'))),
            Tab(child: Text('ஆஃப்லைன்', style: TextStyle(fontFamily: 'NotoSerifTamil'))),
          ],
        ),
      ),
      body: _loading ? const Center(child: CircularProgressIndicator()) : TabBarView(
        controller: _tabController,
        children: [
          _buildBookmarksTab(),
          _buildHistoryTab(),
          _buildOfflineTab(),
        ],
      ),
    );
  }

  Widget _buildBookmarksTab() {
    if (_bookmarks.isEmpty) {
      return const Center(child: Text('நூலகத்தில் புத்தகங்கள் எதுவும் இல்லை', style: TextStyle(fontFamily: 'NotoSerifTamil')));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _bookmarks.length,
      itemBuilder: (ctx, i) {
        final b = _bookmarks[i];
        return ListTile(
          leading: ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: CachedNetworkImage(
              imageUrl: b['coverUrl'] ?? '',
              width: 40, height: 60,
              fit: BoxFit.cover,
              errorWidget: (_, __, ___) => const Icon(Icons.book),
            ),
          ),
          title: Text(b['title'] ?? '', style: const TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 14, fontWeight: FontWeight.bold)),
          subtitle: Text(b['authorName'] ?? '', style: const TextStyle(fontSize: 12)),
          onTap: () => context.push('/novel/${b['slug']}'),
        );
      },
    );
  }

  Widget _buildHistoryTab() {
    if (_history.isEmpty) {
      return const Center(child: Text('வாசிப்பு வரலாறு எதுவும் இல்லை', style: TextStyle(fontFamily: 'NotoSerifTamil')));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _history.length,
      itemBuilder: (ctx, i) {
        final h = _history[i];
        return ListTile(
          title: Text(h['novelTitle'] ?? '', style: const TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 14, fontWeight: FontWeight.bold)),
          subtitle: Text('கடைசியாக வாசித்தது: அத்தியாயம் ${h['chapterNumber'] ?? 1}', style: const TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 12)),
          trailing: Text('${(h['readPercent'] ?? 0).toInt()}% complete', style: const TextStyle(fontSize: 11)),
          onTap: () => context.push('/novel/${h['novelSlug']}'),
        );
      },
    );
  }

  Widget _buildOfflineTab() {
    if (_offlineChapters.isEmpty) {
      return const Center(child: Text('ஆஃப்லைனில் சேமிக்கப்பட்ட அத்தியாயங்கள் இல்லை', style: TextStyle(fontFamily: 'NotoSerifTamil')));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _offlineChapters.length,
      itemBuilder: (ctx, i) {
        final c = _offlineChapters[i];
        return ListTile(
          leading: const Icon(Icons.download_done, color: Color(0xFFE85D26)),
          title: Text(c['title'] ?? '', style: const TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 14, fontWeight: FontWeight.bold)),
          subtitle: Text(c['novelTitle'] ?? '', style: const TextStyle(fontFamily: 'NotoSerifTamil', fontSize: 12)),
          onTap: () => context.push('/read/${c['novelId']}/${c['id']}'),
        );
      },
    );
  }
}
