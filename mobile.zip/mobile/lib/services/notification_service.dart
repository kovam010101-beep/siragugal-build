import 'dart:io';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'api_service.dart';

class NotificationService {
  static final _fcm = FirebaseMessaging.instance;
  static final _localNotifications = FlutterLocalNotificationsPlugin();

  static Future<void> initialize() async {
    // Request permission (iOS/Android 13+)
    await _fcm.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    // Initialize local notifications
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings();
    const initSettings = InitializationSettings(android: androidSettings, iOS: iosSettings);

    await _localNotifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (response) {
        // Handle notification click when app is active/foreground
        if (response.payload != null) {
          _handleDeepLink(response.payload!);
        }
      },
    );

    // Foreground notifications handler
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      final notification = message.notification;
      final android = message.notification?.android;
      if (notification != null) {
        _localNotifications.show(
          notification.hashCode,
          notification.title,
          notification.body,
          NotificationDetails(
            android: AndroidNotificationDetails(
              'siragugal_general',
              'Siragugal Alerts',
              channelDescription: 'New novel releases and system alerts',
              importance: Importance.max,
              priority: Priority.high,
              icon: android?.smallIcon ?? '@mipmap/ic_launcher',
            ),
            iOS: const DarwinNotificationDetails(),
          ),
          payload: message.data['link'],
        );
      }
    });

    // Background/Terminated notification click handler
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      if (message.data['link'] != null) {
        _handleDeepLink(message.data['link']);
      }
    });

    // Get push token and register to backend
    try {
      final token = await _fcm.getToken();
      if (token != null) {
        final platform = Platform.isAndroid ? 'android' : 'ios';
        await apiService.registerPushToken(token, platform);
      }
    } catch (_) {}

    // Auto-refresh token listener
    _fcm.onTokenRefresh.listen((token) async {
      final platform = Platform.isAndroid ? 'android' : 'ios';
      try {
        await apiService.registerPushToken(token, platform);
      } catch (_) {}
    });
  }

  static void _handleDeepLink(String link) {
    // E.g., /read/novelId/chapterId or /novel/slug
    // Trigger deep links via app routers (parsed in go_router setup)
  }
}
